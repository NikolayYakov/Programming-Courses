﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Animals
{
   public class StartUp
    {
         
       static void Main(string[] args)
       {
             
            
                Engine engine = new Engine();
                engine.Run();
             
            
                 
       }
        
    }
 }
